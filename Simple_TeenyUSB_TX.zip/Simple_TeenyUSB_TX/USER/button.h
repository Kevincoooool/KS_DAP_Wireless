/*
 * @Descripttion: 
 * @version: 
 * @Author: Kevincoooool
 * @Date: 2020-06-24 14:09:23
 * @LastEditors  : Kevincoooool
 * @LastEditTime : 2020-10-18 17:12:16
 * @FilePath     : \Simple_TeenyUSB_TX\USER\button.h
 */
#ifndef _TOUCH_H_
#define _TOUCH_H_
#include "stm32f1xx.h"



void Button_Init(void);

#endif

