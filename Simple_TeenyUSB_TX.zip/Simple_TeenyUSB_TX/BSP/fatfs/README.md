FatFs
=====

This is a copy of FatFs, a "generic FAT file system module for small embedded
systems", by ChaN. See http://elm-chan.org/fsw/ff/00index_e.html.

License
=======

FatFs module is a free software that opened under license policy of
following conditions.

Copyright (C) 2015, ChaN, all right reserved.

1. Redistributions of source code must retain the above copyright notice,
   this condition and the following disclaimer.

This software is provided by the copyright holder and contributors "AS IS"
and any warranties related to this software are DISCLAIMED.
The copyright owner or contributors be NOT LIABLE for any damages caused
by use of this software.
