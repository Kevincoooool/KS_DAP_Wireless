老版本的示例代码移到了[此处](https://github.com/xtoolbox/archive_TeenyUSB/tree/master/usb_stack/demo).

Old style demo has been moved to [here](https://github.com/xtoolbox/archive_TeenyUSB/tree/master/usb_stack/demo).