/*
 * @Descripttion: 
 * @version: 
 * @Author: Kevincoooool
 * @Date: 2020-06-24 14:09:23
 * @LastEditors  : Kevincoooool
 * @LastEditTime : 2020-10-30 19:22:03
 * @FilePath     : \Simple_TeenyUSB_TX\USER\button.h
 */
#ifndef _TOUCH_H_
#define _TOUCH_H_
#include "include.h"



void Button_Init(void);

#endif

